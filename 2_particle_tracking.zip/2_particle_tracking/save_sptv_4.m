%==========================================================================
% save_sptv_4.m
%
% Save particle tracks as sptv data (x and y positions and u and v
% velocities)
% 
% Author: B. Davidson
% Last Updated: 3 October 2025
%==========================================================================

clear;
close all;
clc;

%% Data to Process


%location of data

fPath = "../Results";

%load track details
load(strcat(fPath,'/track_details_px_f.mat')) %all particles position and data
load(strcat(fPath,'/time_trim.mat')) %time
N = length(time)-1;

ptv_xyuv = cell(N,1);

%loop through each particle and sort data
for p = 1:length(B)
    part = B{p};
    for i = 1:size(part,1)
        if all(~isnan(part(i,5:6))) && part(i,11) == 0 %if velocities are not nan and particle is not beached
            ptv_xyuv{part(i,3)}(end+1,:) = [part(i,[1 2 5 6])];%append particle location and velocity to the ptv frame

            t = part(i,3);
        end
    end
end

save(strcat(fPath,'/ptv_xyuv.mat'),'ptv_xyuv')

disp("DONE")
