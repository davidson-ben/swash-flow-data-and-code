function [B] = track_details_v2_particle_centroids(partPath,units)
%==========================================================================
% track_details_v2_particle_centroids.m
%
% Input connected particles and output details of each track (velocity,
% acceleration, beaching...)
% 
% Author: B. Davidson
% Last Updated: 3 October 2025
%==========================================================================
    %load connected tracks
    load(strcat(partPath,"/connected_particles.mat"),'connectedParts')
    % connectedParts{i}}(:,1:4)
    % 1st column: X-centroid
    % 2nd column: Y-centroid
    % 3rd column: frame
    % 4th column: particle number

    %load conversion
    load("../1_camera_preprocessing/cc_smooth.mat",'mm_px')


    %% trim by path length

    minTrackLength = 5;
    
    A = connectedParts;
    
    % get the length for each track
    for i = 1:length(A)
        n(i) = size(A{i},1);
    end
    
    %remove tracks shorter than minTrackLength
    for i = 1:length(A)
        if n(i) < minTrackLength
            A{i} = []; % set cells for tracks with length < min to be empty
        end
    end
    B = A(~cellfun('isempty',A)); %remove empty cells
    
    %set up empty cells in B for velocity, acceleration, and beaching
    for i = 1:length(B)
        B{i}(:,5:11) = nan;
    end
    %B_columns = {"X-Centroid (cross-shore)","Y-Centroid (alongshore)","Time","Particle","X-Velocity (cross-shore)","Y-Velocity (alongshore)" + "Velocity Magnitude","X-Accel","Y-Accel","Accel Mag","Beach?"};
    
    % All particles in 'B' have passed the length test (>= 3 steps)
    % Get velocity 
    
    %Beaching Conditions
    v_thresh = 0.4; %set to a small value - if a particle moves by this value or less, it is considered beached
    a_thresh = 0.8; %set to a small value
    

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %This is what I need to look at.
    %
    %Here I will add Gaussian Kernel for Velocity calculation
    %
    %Also add Gaussian Kernel for Acceleration
    %
    %What is minimum number of steps needed for velocity?
    %
    %What is minimum number of steps needed for acceleration?
    %
    %Reconsider beachingh conditions here?  I think I will still do it with
    %velcoity and acceleration - rather than shoreline motion, but see if
    %these values still hold...
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    halfWidth = 1;
    halfSupport = 3;
    %Loop through all tracks
    for part = 1:length(B)
        % X-Vel cross shore velocity
        B{part}(halfSupport+1:end-halfSupport,5) = velocity_fn(B{part}(:,1),halfWidth,halfSupport);
        % Y-Vel alongshore velocity
        B{part}(halfSupport+1:end-halfSupport,6) = velocity_fn(B{part}(:,2),halfWidth,halfSupport);
        % Velocity magnitude
        B{part}(:,7) = sqrt(B{part}(:,5).^2 + B{part}(:,6).^2);

        % X-Accel
        B{part}(halfSupport+1:end-halfSupport,8) = velocity_fn(B{part}(:,5),halfWidth,halfSupport);
        % Y-Accel
        B{part}(halfSupport+1:end-halfSupport,9) = velocity_fn(B{part}(:,6),halfWidth,halfSupport);
        % Acceleration magnitude
        B{part}(:,10) = sqrt(B{part}(:,8).^2 + B{part}(:,9).^2);

        %Beaching?
        vBeach = (B{part}(:,7) <= v_thresh); %frames where particle is likely beached based on velocity only
        aBeach = (B{part}(:,10) <= a_thresh); %frames where particle is likely beached based on acceleration only
        B{part}((vBeach==1) & (aBeach==1),11) = 1; %set to 1 if the particle is likely beached
 
        vFloat = (B{part}(:,7) > v_thresh); %frames where particle is likely NOT beached based on velocity only
        aFloat = (B{part}(:,10) > a_thresh); %frames where particle is likely NOT beached based on acceleration only
        B{part}((vFloat==1) | (aFloat==1),11) = 0; %set to 0 if the particle is likely NOT beached
    end

    %Loop through all tracks and change units
    if strcmp(units,'pixels_frames')
    elseif strcmp(units,'meters_seconds')
        for part = 1:length(B)
            B{part}(:,1) = B{part}(:,1)*mm_px*(1/10); %X-Centroid [px] -> [cm]
            B{part}(:,2) = B{part}(:,2)*mm_px*(1/10); %Y-Centroid [px] -> [cm]
            B{part}(:,3) = B{part}(:,3)*(33)*(1/1000); %Frame [frame] -> [seconds]
            B{part}(:,4) = B{part}(:,4); %Particle number [-]
            B{part}(:,5) = B{part}(:,5)*mm_px*(1/10)*(1/33)*(1000); %X-Velocity [px/frame] -> [cm/s]
            B{part}(:,6) = B{part}(:,6)*mm_px*(1/10)*(1/33)*(1000); %Y-Velocity [px/frame] -> [cm/s]
            B{part}(:,7) = B{part}(:,7)*mm_px*(1/10)*(1/33)*(1000); %Velocity Magnitude [px/frame] -> [cm/s]
            B{part}(:,8) = B{part}(:,8)*mm_px*(1/10)*(1/33)^2*(1000)^2; %X-Acceleration [px/frame^2] -> [cm/s^2]
            B{part}(:,9) = B{part}(:,9)*mm_px*(1/10)*(1/33)^2*(1000)^2; %Y-Acceleration [px/frame^2] -> [cm/s^2]
            B{part}(:,10) = B{part}(:,10)*mm_px*(1/10)*(1/33)^2*(1000)^2; %Acceleration Magnitude [px/frame^2] -> [cm/s^2]
            B{part}(:,11) = B{part}(:,11); %Beaching [-]
        end
    end

end

