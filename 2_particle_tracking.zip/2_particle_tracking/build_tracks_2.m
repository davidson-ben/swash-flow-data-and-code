%==========================================================================
% build_tracks_2.m
%
% JAI camera image processing for SWQUEENS experiments from summer 2024.
% 
% 
% After camera image preprocessing and finding particle locations, this
% code connects particle locations into tracks.  Tracking code based upon
% "tracker_v16.m" from N. Pujara.
% 
% Author: B. Davidson
% Last Updated: 4 April 2025
%==========================================================================
clear; close all; clc;

folderPath = "../Results";
load(strcat(folderPath,"/particle_locations.mat"))
connectedParts = track_parts(pts);

% build tracks
save(strcat(folderPath,"/connected_particles.mat"),"connectedParts")


frames = cell(length(pts),1);
% sort by frame
for pt = 1:length(connectedParts)
    for i = 1:size(connectedParts{pt},1)
        frames{connectedParts{pt}(i,3)}(end+1,:) = connectedParts{pt}(i,:);
    end
end

%sort by frame
save(strcat(folderPath,"/connected_particles_byframe.mat"),'frames')

disp('DONE')

