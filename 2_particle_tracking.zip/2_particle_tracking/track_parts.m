function [parts_tracked] = track_parts(frameParts)
%==========================================================================
% track_parts.m
% code based upon "tracker_v16.m" from Nimish Pujara
%
%   Given particle centroids in each image, track particles through image
%   series and group into tracks.  Cite Ouellette 4FBE algorithm.
% 
% Author: B. Davidson
% Last Updated: 4 April 2025
%==========================================================================

    time = 1:length(frameParts);
    
    xydist_thresh = 30; % px (relates to noise in position)
    
    % preparation of output data structure
    parts_tracked = cell(0); %[x-centroid y-centroid time track]
    itrack = 0; %global track index
    opentracks = []; %global track indices of open tracks
    
    % tracking loop
    % open new tracks with all particles that are in the first frame
    frame = 1;
    if ~isempty(frameParts{frame})
        x1 = frameParts{frame}(:,1);
        y1 = frameParts{frame}(:,2);
    else
        x1 = [];
        y1 = [];
    end
    t1 = time(frame);
    for ixa = 1:length(x1)
        itrack = itrack + 1; %new track numbers
        parts_tracked{ixa,1}(1,:) = [x1(ixa) y1(ixa) t1 itrack];
    end

    %indices of all open tracks
    opentracks = 1:itrack;
 
    %loop through all frames and look to match particles to open tracks
    for frame = 2:length(frameParts)-1
    
        %if there are no particles in this frame, kill all open tracks and go
        %to the next frame
        if isempty(frameParts{frame})
            opentracks = [];
            continue;
        end
    
        %all particles at current time
        xi = frameParts{frame}(:,1);
        yi = frameParts{frame}(:,2);
        ti = time(frame);
    
        %if no open tracks exist, start new tracks with particles in this frame
        %and go to next frame
        if isempty(opentracks)
            %look up how many tracks are already closed
            itrack = size(parts_tracked,1);
            %indices of tracks about to be opened
            opentracks = itrack+1:itrack+length(xi);
            %open new trakcs
            for ixa = 1:length(xi)
                itrack = itrack + 1;
                parts_tracked{itrack,1}(1,:) = [xi(ixa) yi(ixa) time(frame) itrack];
            end
    
            continue;
        end
    
        %
        % create empty array for best matching particle for each open track
        bestmatch = nan(1,length(opentracks));
    
        %loop through all open tracks and consider particles in this frame for
        %match to each track
        for iopentracks = 1:length(opentracks)
    
            %index for this open track
            itrack = opentracks(iopentracks);
    
            %%%%%%%
    
            % Particle velocity from previous position (if applicable) to
            % current position
            %
            %check if track is more than one step long
            if size(parts_tracked{itrack,1},1)>1
                %if the track is at least 2 entries long, we use the last and
                %current location to estimate the velocity
                ui = parts_tracked{itrack,1}(end,1) - parts_tracked{itrack,1}(end-1,1);
                vi = parts_tracked{itrack,1}(end,2) - parts_tracked{itrack,1}(end-1,2);
            else
                %if the track is only 1 frame long, estimated velocites are zero and
                %best match will default to the nearest neighbor
                ui = 0;
                vi = 0;
            end
            
            %estimate current positions using estimated velocities
            xie = parts_tracked{itrack,1}(end,1) + ui;
            yie = parts_tracked{itrack,1}(end,2) + vi;
    
            %calculate difference between expected and found positions
            diff_xi = xi - xie;
            diff_yi = yi - yie;
            diff_xydist = (diff_xi.^2 + diff_yi.^2).^(0.5);
    
            % if there is only 1 particle in this frame, it may be a match
            % or if the track is only 1 long so far
            % use nearest neighbor heuristic
            if length(diff_xydist)==1 || size(parts_tracked{itrack,1},1)==1
                candidate_index = (diff_xydist < xydist_thresh); %possible candidates must be within position threshold
                if length(find(candidate_index))==1
                    %if there is only one match, then this particle is
                    %chosen as the best match
                    bestmatch(iopentracks) = find(candidate_index);
                elseif length(find(candidate_index))>1
                    %if there is more than one match, then the chosen best
                    %match is the position that minimizes the distance
                    %between the particle location and expected location.
                    [min_xydist, min_xyind] = min(diff_xydist);
                    bestmatch(iopentracks) = min_xyind;
                end
                continue
            end
            
            %calculate estimated position in the next frame using velocity and
            %acceleration estimates
    
            %expected position
            x2e = nan(length(xi),1); 
            y2e = nan(length(xi),1);

            %velocity
            u2 = nan(length(xi),1); 
            v2 = nan(length(xi),1);

            %acceleration
            uacc = nan(length(xi),1); 
            vacc = nan(length(xi),1); 

            %indices of all candidates (all particles within range of expected location)
            candidate_index = diff_xydist<xydist_thresh;

            if length(find(candidate_index))>=1
                %If there is AT LEAST ONE candidate, use 4 frame best estimate

                %particle velocity from current position to candidate position  
                u2(candidate_index) = xi(candidate_index) - parts_tracked{opentracks(iopentracks),1}(end,1);
                v2(candidate_index) = yi(candidate_index) - parts_tracked{opentracks(iopentracks),1}(end,2);

                %particle acceleration from previous position, through current position, to candidate position
                uacc(candidate_index) = (xi(candidate_index) -2*parts_tracked{opentracks(iopentracks),1}(end,1) +parts_tracked{opentracks(iopentracks),1}(end-1,1))/2;
                vacc(candidate_index) = (yi(candidate_index) -2*parts_tracked{opentracks(iopentracks),1}(end,2) +parts_tracked{opentracks(iopentracks),1}(end-1,2))/2;
                
                %estimate particle position in the 4th frame with velocity and acceleration (no 0.5 on acceleration due to numerical integration.)
                x2e(candidate_index) = parts_tracked{opentracks(iopentracks),1}(end,1) + 2*(ui + u2(candidate_index))/2 + (2^2)*uacc(candidate_index);
                y2e(candidate_index) = parts_tracked{opentracks(iopentracks),1}(end,2) + 2*(vi + v2(candidate_index))/2 + (2^2)*vacc(candidate_index);
    
                %look at next frame
                frame2 = frame + 1;
    
                % if there are no particles in the next frame, choose the
                % nearest to the expected in this frame and go to the next
                % track
                if isempty(frameParts{frame2})
                    candidate_index = diff_xydist<xydist_thresh;
                    if length(find(candidate_index))==1
                        bestmatch(iopentracks) = find(candidate_index);
                    elseif length(find(candidate_index))>1
                        [min_xydist, min_xyind] = min(diff_xydist);
                        bestmatch(iopentracks) = min_xyind;
                    end
                    continue
                end
    
                %find all particles in the next frame
                x2 = frameParts{frame2}(:,1);
                y2 = frameParts{frame2}(:,2);
                t2 = time(frame2);
    
                %calculate difference between expected and found positions in the next frame
                diff_xp2 = nan(length(x2e),length(x2));
                diff_yp2 = nan(length(y2e),length(y2));
                diff_dist2 = nan(length(x2e),length(x2));
                for ixa2 = 1:length(x2)
                    diff_xp2(candidate_index,ixa2) = x2(ixa2) - x2e(candidate_index);
                    diff_yp2(candidate_index,ixa2) = y2(ixa2) - y2e(candidate_index);
                    diff_dist2(candidate_index,ixa2) = (diff_xp2(candidate_index,ixa2).^2 + diff_yp2(candidate_index,ixa2).^2).^(0.5);
                end
                %calculate minimum distance between expected position and an actual particle for each candidatae
                [min_dist2,~] = min(diff_dist2,[],2,'omitnan'); %2nd dimension minimum - closest particle to each predicted position
    
                %best match is particle with minimum difference between the expected position and an actual particle for each candidate
                [min_dist, min_ind] = min(min_dist2,[],'omitnan'); %minimize distance between found particle and predicted position overall
                bestmatch(iopentracks) = min_ind;
            end
        end
    
        %decide fate of each track
        trackfate = true(1,length(opentracks));
        for iopentracks = 1:length(opentracks)
            %kill those that did not find a particle match and those where the same particle matches to multiple tracks
            if isnan(bestmatch(iopentracks)) || length(find(bestmatch==bestmatch(iopentracks)))>1
                trackfate(iopentracks) = false;
    
            %where a particle matched to only 1 track, extend the track
            else
                parts_tracked{opentracks(iopentracks),1}(end+1,:) = [xi(bestmatch(iopentracks)) yi(bestmatch(iopentracks)) time(frame) opentracks(iopentracks)];
            end
        end
        %kill tracks
        opentracks = opentracks(trackfate);
        bestmatch = bestmatch(trackfate);
    
        %open new tracks with particles that did not match to open tracks
        for ixa = 1:length(xi)
            if isempty(find(bestmatch==ixa,1))
                itrack = size(parts_tracked,1)+1;
                opentracks(end+1) = itrack;
                parts_tracked{itrack,1}(1,:) = [xi(ixa) yi(ixa) time(frame) itrack];
            end
        end
    end
    
    % remove tracks with only one step
    for i = 1:length(parts_tracked)
        if size(parts_tracked{i,1},1) < 2
            parts_tracked{i,1} = [];
        end
    end
    parts_tracked = parts_tracked(~cellfun('isempty',parts_tracked));

end