%==========================================================================
% ens_av_ptv_scatter.m
%
% JAI camera image processing for SWQUEENS experiments from summer 2024.
% 
% Save and plot scatter data of SPTV with ensemble average.
% 
% Author: B. Davidson
% Last Updated: 3 October 2025
%==========================================================================
clear;
close all;
clc;

%load(strcat(fPath,'ptv.mat'),'ptv_xyuv') %particle positions and velocities
%eorror('Need to use updated positions and velocities')



[frame_time,time_cyc] = ensemble_avg_frames;
    %frame_time is the time in seconds since the camera starts
    %time_cyc is the corresponding time in the swash cycle for the respective frame

load("../1_camera_preprocessing/A00_SWL.mat")
x_ref = X_swl;
clear X_swl

path = "../Results";


%% DATA

%load PTV data
load(strcat(path,'/ptv_xyuv.mat'),'ptv_xyuv')

%load PTV time
load(strcat(path,'/time_trim.mat'))
time(end) = [];
ptv_time = time - 360;


%put PTV velocity onto camera frames
frame_time; % velocity already on the frame

u_PTV = nan(size(frame_time));
A = round(frame_time,3);
B = round(ptv_time,3);
[C_PTV, ia_PTV, ib_PTV] = intersect(A,B);

load("../1_camera_preprocessing/cc_smooth.mat")

%LOAD SHORELINE DATA
load(strcat(path,'/shoreline.mat'))
dt_shoreline = 0.0330;
shoreline_time = 0:dt_shoreline:(size(wave,1)-1)*dt_shoreline;

Mxs = nan(size(frame_time));
A = round(frame_time,3);
B = round(shoreline_time,3);
[C_shoreline, ia_shoreline, ib_shoreline] = intersect(A,B);


%ia is index on A that corresponds to B
for i = 1:length(ib_shoreline)
    Mxs(ia_shoreline(i)) = mean(wave(ib_shoreline(i),:));
end


%% Setup

dx = -30; %~25mm
X = 2464:dx:0;
T = linspace(0,2,61)'; %linspace(0,2,61); 0 and 2 are the same!  Keep this in mind.
Ue = nan(length(X),length(T));



%% EA - PTV Scatter

for step = 1:length(X)
    x_inq = X(step);
    hwx = 30; %25
    
    %ia is index on A that corresponds to B
    for i = 1:length(ib_PTV)
        if ~isempty(ptv_xyuv{ib_PTV(i)})
            xs{i} = ptv_xyuv{ib_PTV(i)}(:,1);
            us{i} = ptv_xyuv{ib_PTV(i)}(:,3);
            ts{i} = time_cyc(ia_PTV(i));
        end
    end
    
    %Convert PIV velocity from px/frame to m/s
    %u_PTV = -1*u_PTV*30.3*mm_px/1000;
    

end

figure(1)
clf
hold on

xp = [];
tp = [];
up = [];

for i = 1:length(ts)
    if ~isnan(ts{i})
        xp = [xp; (x_ref - xs{i})*mm_px/1000];
        tp = [tp; ones(size(xs{i}))*ts{i}];
        up = [up; -1*us{i}*mm_px/1000*30.3];
    end
end

scatter(tp,xp,10,up,'filled')
colorbar

xlabel('time [s]')
ylabel('Cross-shore position [m]')
set(gca,'FontSize',15)
title("Velocity Field")

savepath = [];

savename = strcat(path,'/EA_uxt','.mat');
save(savename,'xp','tp','up')
disp("DONE.")
