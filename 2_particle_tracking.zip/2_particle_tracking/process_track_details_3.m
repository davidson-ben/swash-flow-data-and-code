%==========================================================================
% save_track_details_3.m
%
% JAI camera image processing for SWQUEENS experiments from summer 2024.
% 
% Go through all tracks and save track details.
% 
% Author: B. Davidson
% Last Updated: 17 April 2025
%==========================================================================
clear;
close all;
clc;


%load particle locations

partPath = "../Results";
    
units = 'pixels_frames';
B = track_details_v2_particle_centroids(partPath,units);
B_columns = {"X-Centroid (cross-shore)","Y-Centroid (alongshore)","Time","Particle","X-Velocity (cross-shore)","Y-Velocity (alongshore)","X-Accel","Y-Accel","Beach?"};

if strcmp(units,'pixels_frames')
    B_units = {"[px]","[px]","[frames]","[-]","[px/f]","[px/f]","[px/f]","[px/f^2]","[px/f^2]","[px/f^2]","[-]"};
    save(strcat(partPath,'/track_details_px_f.mat'),'B','B_columns','B_units')
elseif strcmp(units,'meters_seconds')
    B_units = {"[cm]","[cm]","[seconds]","[-]","[cm/s]","[cm/s]","[cm/s]","[cm/s^2]","[cm/s^2]","[cm/s^2]","[-]"};
    save(strcat(partPath,'/track_details_cm_s.mat'),'B','B_columns','B_units')
end

disp("DONE.")