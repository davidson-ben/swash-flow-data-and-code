%==========================================================================
% find_particles_1.m
%
% JAI camera image processing and calibration SWQUEENS experiments from summer 2024.
% 
% Takes rectified swash images and processes to find tracer particles for sptv data.
% 
% Author: B. Davidson
% Last Updated: 16 September 2025
%   Updated to get centroid from the first moment of blob using pixel
%   intensity from filtered image.
%==========================================================================

clear
close all
clc

start_frame = 250;

projectDir = "../Results";
cd(projectDir)
tifFiles = dir("../SPTV_Images");

%remove directory and hiden files
if tifFiles(1).name=='.'
    tifFiles(1) = [];
end
if tifFiles(1).name=='..'
    tifFiles(1) = [];
end
if tifFiles(1).name=='.DS_Store'
    tifFiles(1) = [];
end
if tifFiles(end).name=='Thumbs.db'
    tifFiles(end) = [];
end

%tifFiles = tifFiles(arrayfun((@f) f.name(1) ~= '.', tifFiles));

%% calculate background
if exist(fullfile('background.mat'),"file")==0

    start = start_frame + 1; %first frame is labeled 0
    % Only select background frames from valid
    
    
    %For background we don't need to save all images, let's use 100 random
    %images
    back_inds = round(rand(200,1)*length(tifFiles)); %200 random frames between 1 and total number of frames
    back_inds(back_inds==0) = []; %remove zeros
    back_inds = unique(back_inds); %no duplicates
    
    %disp('REMOVE ANY FRAMES OUTSIDE OF PTV START RANGE')
    back_inds(back_inds<start) = [];
    
    if length(back_inds)<100
        error('Less than 100 random frames chosen - retry')
    else
        back_inds = back_inds(1:100);
    end

    backs = nan(2056,2464,100);
    
    for i_b = 1:length(back_inds) %loop through background index file
        name = tifFiles(back_inds(i_b)).name; %file name
    
        % load frame
        backs(:,:,i_b) = imcomplement(uint8(mean(imread(strcat("../SPTV_Images/",name)),3))); %load image as inverted frame mean
    
        disp(strcat(string(i_b),'/100'))
    end
    
    background = uint8(mean(backs,3));
    
    disp('Background Computed')

    save('background.mat','background','start')

else
    load('background.mat','background','start')
    disp('Saved background loaded.')
end

%% Go through each image, remove background, lowpass, binarize, and save the original image at binarized indices
disp('Process each image')
N = length(tifFiles);

parfor f = start:N %going through each frame now
    name = tifFiles(f).name; %file name
    num_str = regexp(name, '^\d{4}', 'match');
    I = imcomplement(uint8(mean(imread(strcat("../SPTV_Images/",name)),3))); %load image, mean, and invert
    lp = 20;
    frame_in = I - background;
    [B, B_mask] = frame_process(frame_in,lp); %binarized image

    %particle centroids
    p = regionprops(B,'Centroid','Area','EquivDiameter','PixelList');

    %update centroids
    Centroid_Moment = nan(length(p),2);
    for i = 1:length(p)
        %all pixel locations in the cluster
        xy = p(i).PixelList;

        %pixel intensities
        int = nan(size(xy,1),1);
        for j = 1:size(xy,1)
            int(j) = double(B_mask(xy(j,2),xy(j,1)));
        end
    
        %Total intensity
        M = sum(int);

        %X and Y centroids
        xc = sum(int.*xy(:,1))/M;
        yc = sum(int.*xy(:,2))/M;
        Centroid_Moment(i,:) = [xc yc];
    end
    
    %Append Centroid_Moment to p structure
    for i = 1:length(p)
        p(i).Centroid_Moment = Centroid_Moment(i,:);
    end

    pts{f} = [vertcat(p.Centroid_Moment) vertcat(p.Area) vertcat(p.EquivDiameter)];
    disp(strcat(string(f),"/",string(N)))
end


save('particle_locations.mat',"pts")

disp('DONE')


function [B,B_mask] = frame_process(I_in,lowpass)
    lowfilt = medfilt2(I_in, [lowpass lowpass]);
    I_filt = I_in - lowfilt;

    B = imcomplement(imbinarize(imcomplement(I_filt),'adaptive','Sensitivity',0.7));
    B_mask = I_filt;
    B_mask(B==0) = 0;

    
    %For PIV we wanted the original image masked showing only the
    %particles, but now for particle locations, we just want the binarized
    %image.
    %I_out = uint8(B).*I_filt;
end