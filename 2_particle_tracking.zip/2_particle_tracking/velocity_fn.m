function [velocities] = velocity_fn(positions,halfWidth,halfSupport)
%VELOCITY_FROM_POSITION
%==========================================================================
% velocity_fn.m
% Function to find velocity from position data with gausian convolution.
% 
% Mordant N, Crawford AM, Bodenschatz E. 2004. Experimental Lagrangian acceleration probability density function measurement. Physica D: Nonlinear Phenomena. 193(1-4):245–51
% Ouellette NT, XU H, Bodenschatz E. 2006. A quantitative study of three-dimensional Lagrangian particle tracking algorithms. Exp Fluids. 40:301–13
%==========================================================================

    % define parameters for Gaussian, differentiation kernel
    dt = 1; % in frames

    % If halfWidth == 1, then this is a filter width of two frames (1 frame half width)
    fw = halfWidth*dt; % filter width in frame (half width) 

    % If halfSupport == 2, then this is a filter support of 5 frames (2 frames on either side)
    fL = halfSupport*fw; % filter integration halfwidth (half support)

    A = 1/((fw^2)*(fL)*exp(-(fL/fw)^2) - ((fw^3)/2)*sqrt(pi)*erf(fL/fw)); % from normalization condition
    % kernel:
    k = A*(-fL:dt:fL).*exp(-((-fL:dt:fL)/fw).^2);
    velocities = conv(positions,k,'valid');
end






