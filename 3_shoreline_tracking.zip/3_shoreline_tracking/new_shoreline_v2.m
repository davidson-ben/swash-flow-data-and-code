%==========================================================================
% new_shoreline_v2.m
%
% Enhance optical shoreline with SPTV results to better identify shoreline
% near the maximum wave run-up location.
% 
% Author: B. Davidson
% Last Updated: 3 October 2025
%==========================================================================

clear;
close all;
clc;

%plot velocity field

%choose region for current shoreline (maybe 0 to 0.5s?)
%use pink diamonds (or similar) in the middle
%use filtered stars at the end


%load(strcat(fPath,'ptv.mat'),'ptv_xyuv') %particle positions and velocities
%eorror('Need to use updated positions and velocities')


[frame_time,time_cyc] = ensemble_avg_frames;
    %frame_time is the time in seconds since the camera starts
    %time_cyc is the corresponding time in the swash cycle for the respective frame


load("../1_camera_preprocessing/A00_SWL.mat")
x_ref = X_swl;
clear X_swl


path = "../Results";
load("../1_camera_preprocessing/cc_smooth.mat")

%% Load Shoreline

%LOAD SHORELINE DATA
load(strcat(path,'/shoreline.mat'))
dt_shoreline = 0.0330;
shoreline_time = 0:dt_shoreline:(size(wave,1)-1)*dt_shoreline;

Mxs = mean(wave,2);

Mxs = medfilt1(Mxs,6);


%% Load EA - PTV

load(strcat(path,'/EA_uxt.mat'),'xp','tp','up') %load EA PTV data


%% EA shoreline position

T = linspace(0,2,121);

xs_ea = nan(size(T));

hw_t = diff(T(1:2))*2;

for i = 1:length(xs_ea)
    low = T(i)-hw_t;
    high = T(i)+hw_t;
    if low <= 0
        low = low + 2;
        is = find(time_cyc <= high | time_cyc >= low);
    elseif high >= 2
        high = high - 2;
        is = find(time_cyc <= high | time_cyc >= low);
    else
        is = find(time_cyc <= high & time_cyc >= low);
    end

    not_nan(i) = sum(~isnan(Mxs(is)));
    if not_nan(i) >= 1
        xs_ea(i) = mean(Mxs(is),'omitnan');
    end
end

xs_ea = (x_ref - xs_ea)*mm_px/1000;


figure(1)
clf
plot(time_cyc,(x_ref - Mxs)*mm_px/1000,'k.')
hold on
plot(time_cyc+2,(x_ref - Mxs)*mm_px/1000,'k.')
ylim([-0.6 1.2])
plot(T,xs_ea,'r-','linewidth',2)
plot(T+2,xs_ea,'r-','linewidth',2)

%% New shoreline

xs_vel = nan(length(T),1);
xs_max = nan(length(T),1);

for i = 1:length(xs_vel)
    %all X on range t_low to t_high
    low = T(i)-hw_t;
    high = T(i)+hw_t;
    if low < 0
        low = low + 2;
        ti = tp(tp>low | tp<=high);
        xi = xp(tp>low | tp<=high);
        ui = up(tp>low | tp<=high);
    elseif high > 2
        high = high - 2;
        ti = tp(tp>low | tp<=high);
        xi = xp(tp>low | tp<=high);
        ui = up(tp>low | tp<=high);
    else
        ti = tp(tp>low & tp<=high);
        xi = xp(tp>low & tp<=high);
        ui = up(tp>low & tp<=high);
    end

    if T(i) <=1.5
        vel_thresh = 0.2;
        xs_vel(i) = max(xi(ui>vel_thresh));
    else
        xs_vel(i) = max(xi);
    end

    xs_max(i) = max(xi);
end

%% Plot

figure(1)
clf
hold on

scatter(tp,xp,10,up,'filled')
colorbar
xlabel('time [s]')
ylabel('Cross-shore position [m]')
title({'Cross-shore velocity [m/s]'})
set(gca,'FontSize',15)

plot(T,xs_ea,'k-','linewidth',1.5)
plot(T,xs_vel,'r--','linewidth',1.5)
plot(T,xs_max,'c-','linewidth',1.5)

tt_new = [T-2 T T+2];
xs_ea_3 = [xs_ea xs_ea xs_ea];
xs_vel_3 = [xs_vel xs_vel xs_vel];
xs_max_3 = [xs_max xs_max xs_max];
xs_new = nan(size(tt_new));

%add optical shoreline
opt_start = T(xs_ea == min(xs_ea))-2; %start of the optical shoreline (min shoreline location) -- subtract 2 because in the leading in cycle
opt_end = 0.5; %intersection chosen by eye
xs_new(and(tt_new>= opt_start, tt_new < opt_end)) = xs_ea_3(and(tt_new>= opt_start, tt_new < opt_end));

%add velocity shoreline
vel_start = opt_end;
vel_end = 2; %end of cycle
xs_new(and(tt_new>= vel_start, tt_new < vel_end)) = xs_vel_3(and(tt_new>= vel_start, tt_new < vel_end));

%add end of cycle shoreline
max_start = 2;
max_end = 2.48;
xs_new(and(tt_new>= max_start, tt_new < max_end)) = xs_max_3(and(tt_new>= max_start, tt_new < max_end));



plot(tt_new,xs_new,'ko--','linewidth',2,'markerfacecolor','k')

t_shore = tt_new;
x_shore = xs_new;

save(strcat(path,'/combined_shoreline_ea.mat'),'t_shore','x_shore')


