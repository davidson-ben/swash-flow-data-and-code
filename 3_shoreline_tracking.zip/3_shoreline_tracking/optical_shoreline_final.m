%==========================================================================
% optical_shoreline_final.m
%
% Optical shoreline tracking based on visual identification of the leading
% edge of the swash front.
% 
% Author: B. Davidson
% Last Updated: 3 October 2025
%==========================================================================
clear;
close all;
clc;

im_path = "../SPTV_Images";
save_path = "../Results";

%image files
files = dir(strcat(im_path,"/*.tif"));
files = files(~startsWith({files.name}, '._'));

%% Load Background
load(strcat(save_path,'/background.mat'),'background','start')
background = imcomplement(background);

edges = 1:400:2056;
bins = (edges(2)/2)+edges(1:end-1);
wave = cell(length(files),1);
for i = 1:length(wave)
    wave{i} = nan(1,length(bins));
end
poly_degree = 4;
%%
parfor fm = start:length(files)
    t = Tiff(strcat(files(fm).folder,'/',files(fm).name),'r');
    A = read(t);
    B = medfilt2(A,[10 10])-background;
    C = medfilt2(B,[20 20]);


    for b = 1:length(bins)
        strip = C(edges(b):edges(b+1),:);
        line = mean(strip,1);
        threshold = mean(line) + 2 * std(line); % adaptive threshold
        gthresh = find(line > threshold);
        if ~isempty(gthresh)
            wave{fm}(b) = gthresh(1);
        else
            wave{fm}(b) = nan;
        end
    end
    % 
    % hold off
    % imshow(C,[0 10])
    % hold on
    % plot(wave(fm,:),bins,'ro','MarkerFaceColor','r','MarkerSize',5)
    % drawnow()
    % pause(0.1)

    wv = wave{fm}(b);
    % m = mean(wv);
    % s = std(wv);
    % wv(wv>(m+1*s)) = nan;
    % wv(wv<(m-1*s)) = nan;
    %wave(fm,:) = wv;
    if sum(~isnan(wv)) < 5 %if less than 5 valid points
        wv = nan(size(wv));
    end
    % hold off
    % imshow(A)
    % hold on
    % plot(wv,bins,'rx','MarkerSize',5,'LineWidth',2)
    % 
    % 
    % p(fm,:) = polyfit(bins(~isnan(wv)),wv(~isnan(wv)),poly_degree);
    % plot(polyval(p(fm,:),bins(1):bins(end)),bins(1):bins(end),'r','linewidth',2)
    % drawnow()
    % pause(0.1)
    disp(strcat(string(fm),"/",string(length(files))))
end


%% Now switch wave back to double

wave_save = nan(length(wave),length(wave{1}));
for i = 1:length(wave)
    wave_save(i,:) = wave{i};
end

clear wave
wave = wave_save;
clear wave_save
%%

savePath = strcat(save_path,"/shoreline.mat");


save(savePath,'bins','poly_degree','wave')

disp("DONE")