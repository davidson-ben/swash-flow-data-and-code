%==========================================================================
% depth_field.m
%
% Interpolate depth field in the swash zone from local sensors.
% 
% Author: B. Davidson
% Last Updated: 3 October 2025
%==========================================================================
clear;
close all;
clc;

path = "../Results";

%load shoreline (combined) - best run-up
load(strcat(path,'/combined_shoreline_ea.mat'),'x_shore')

%% Load Data
load WG_locs.mat %WG LOCATIONS

load("../1_camera_preprocessing/A00_SWL.mat")
xs0 = X_swl;
clear X_swl;


load('../1_camera_preprocessing/cc_smooth.mat') %mm/px conversion

%load ensemble averaged depth relative to SWL
    %load(strcat('/Volumes/npujara/Ben Davidson/0_Active_Processing/000 - QU Clean EA/depth_ensemble_average_',ref,'.mat'))
load(strcat(path,'/depth_ensemble_average.mat'))

% Need 4 x locations of sensors
x = [A5_px(1) B5_px(1) B6_px(1) A6_px(1)];


max_xs = max(x_shore);
% Add x location of max run-up as last point
x = [x max_xs];

%convert x locations to distance in meters relative to SWL
x = (xs0-x)*mm_px/1000;



%save depth over space
xd = -0.6:0.05:1.8;
td = linspace(0,2,61);

[T,X] = meshgrid(td,xd);
D = nan(size(T));


figure(2)
for i = 1:61
    clf
    hold on
    plot([-0.6 1.8],[-0.6 1.8]*(1/10),'k-','linewidth',2)
    plot([-0.6 0],[0 0],'b--','linewidth',1)
    ylim([-0.06 0.6])
    xlim([-0.6 1.8])
    xlabel('x [m]')
    ylabel('z [m]')
    set(gca,'FontSize',20)
    
    % %sensors
    % for se = 1:length(x)
    %     xline(x(se),'r--')
    % end

    d = [deA{2}(i,2) deB{2}(i,2) deB{1}(i,2) deA{1}(i,2) 0];
    y = d + x/10;
    
    plot(x(1),y(1),'ro','markerfacecolor','r')

    plot(x(2),y(2),'ro','markerfacecolor','r')
    plot(x(3),y(3),'ro','markerfacecolor','r')

    plot(x(4),y(4),'ro','markerfacecolor','r')
    plot(x(5),y(5),'ro','markerfacecolor','r')

    % Model function: y = a*x.^2 + b*x + c
    modelFun = @(b,x) b(1)*x.^2 + b(2)*x + b(3);
    
    % Initial guess for parameters [a, b, c]
    beta0 = [1, 1, 1];
    
    % Fit
    [beta, ~, ~, ~, MSE, ~] = nlinfit(x, d, modelFun, beta0);

    err = sqrt(MSE);

    %plot fit
    xfit = -0.6:0.1:1.8;
    dfit = modelFun(beta, xfit); %local depth

    plot_err(xfit,dfit,err,max(x))
    % % % %dfit(dfit<0) = 0; %set negative depth as zero
    % % % yfit = dfit + xfit/10; %fit in y coords.
    % % % plot(xfit, yfit, 'r-')
    % % % 
    % % % ME = sqrt(MSE); %mean error -> av. dist. between fit and actual points
    % % % 
    % % % %plot errorbars
    % % % xer = -0.5:0.1:1.5;
    % % % yer = modelFun(beta,xer)+xer/10;
    % % % errorbar(xer,yer,errors,'o')

    drawnow()




    %Save Depth Fit
    dd = modelFun(beta,xd);
    dd(dd<0) = nan;
    dd(xd>max(x)) = nan;
    D(:,i) = dd;


end







%% fit depth over space
figure(2)
clf
contourf(T,X,D,50,'linecolor','none')

colorbar
caxis([0 0.15])
colormap sky

xlabel('t [s]')
ylabel('x [m]')
set(gca,'FontSize',20)


Td = T;
Xd = X;
Dd = D;


%% REMOVE DEPTH ABOVE SHORELINE
load('../Results/combined_shoreline_ea.mat')
hold on
plot(t_shore,x_shore,'k-','linewidth',2)

for i = 1:size(D,2)
    ts = T(1,i);
    xs = mean(x_shore(t_shore>ts-0.0333/2 & t_shore<ts+0.0333/2));
    D(X(:,i)>xs,i) = nan;
end

figure(2)
clf
contourf(T,X,D,50,'linecolor','none')
hold on
plot(t_shore,x_shore,'k-','linewidth',2)

colorbar
caxis([0 0.15])
colormap sky

xlabel('t [s]')
ylabel('x [m]')
set(gca,'FontSize',20)


Td = T;
Xd = X;
Dd = D;

%%
save(strcat(path,'/ea_depth_field.mat'),'Td','Xd','Dd')




function plot_err(xfit,dfit,err,xmax)
    dfit(dfit<0) = 0;


    d_high = dfit + err;
    d_low = dfit - err;

    d_high(d_high<0) = 0;
    d_low(d_low<0) = 0;

    dfit(xfit>xmax) = 0;
    d_high(xfit>xmax) = 0;
    d_low(xfit>xmax) = 0;

    y_high = d_high + xfit/10;
    y_low = d_low + xfit/10;
    yfit = dfit + xfit/10;

    yp = [y_high fliplr(y_low)];
    xp = [xfit fliplr(xfit)];

    %plot main
    plot(xfit,yfit,'b-','linewidth',1)

    %plot error
    fill(xp,yp,'r','facecolor','cyan','facealpha',0.25,'edgecolor','none')

end
