%==========================================================================
% contours_model.m
%
% Figure 3 - model
% Plot individual panels for Figure 3 - model results.
% Run each section individually to create each panel.
% 
% Author: B. Davidson
% Last Updated: 3 October 2025
%==========================================================================

%% Plot Antuono Model
clear;
clc;
close all;

alpha = 2.4607;%2.5237; %2.5245
%load antuono solution
load(strcat('/Volumes/npujara/Ben Davidson/0_Active_Processing/14 - Antuono/BD Code/alpha2_',string(alpha),'.mat'),'X','D','T','U','t0','ts_a','xb_a','alpha2')

%constants
h0 = 0.18;
s = 1/10;
g = 9.81;

%make model dimensional
X = X*h0/s;
T = (T-t0)*(sqrt(h0/g)/s);
U = U*sqrt(g*h0);
D = D*h0;

A = U + 2*sqrt(D*g) + g*s*T;
%A = alpha2*ones(size(U)) + 1e-6*rand(size(U));
%A(isnan(U)) = nan;

ts_a = (ts_a-t0)*(sqrt(h0/g)/s);
xb_a = xb_a*h0/s;

%Gradient
dudx = nan(size(U));
x = X(1,:);
t = T(:,1);

for ti = 1:length(t)
    dudx(ti,:) = gradient(U(ti,:),diff(x(1:2)));
end

addpath('/Users/bendavidson/Documents/MATLAB/crameri_colormaps')

return
%% Plot Velocity


figure(1)
clf
hold on
plot(ts_a-2,xb_a,'k-','linewidth',2)
contourf(T-2,X,U,-1:0.1:0.75,'linecolor','none')
plot(ts_a,xb_a,'k-','linewidth',2)
contourf(T,X,U,-1:0.1:0.75,'linecolor','none')
plot(ts_a+2,xb_a,'k-','linewidth',2)
contourf(T+2,X,U,-1:0.1:0.75,'linecolor','none')
set(gca,'FontSize',25)

%labels and ticks
xlabel('$t$ [s]','interpreter','latex','FontSize',40)
xlim([-1 3])
xticks(-1:0.5:3)
xticklabels({'-1.0','','0.0','','1.0','','2.0','','3.0'})
ylabel('$x$ [m]','interpreter','latex','FontSize',40)
ylim([-0.6 1.8])
yticks(-0.6:0.6:1.8)
yticklabels({'-0.6','0.0','0.6','1.2','1.8'})
set(gca,'TickDir','both')



%colorbar
c = colorbar;
clim([-0.75 0.75])
c.Ticks = -0.5:0.25:0.5;
c.TickLabels = {'-0.50','-0.25','0.00','0.25','0.50'};
c.Label.String = '$u$ [m/s]';
c.Label.Interpreter = 'latex';
c.Label.FontSize = 40;
set(c.Label,'position',[4.1938-2.5 0+0.95 0],'rotation',0);
set(gca,'DataAspectRatio',[2 1 1])
crameri -roma

% Force Painters renderer (vector-friendly)
set(gcf, 'Renderer', 'Painters');
shading flat;

return

%% Plot Depth

figure(1)
clf
hold on
plot(ts_a-2,xb_a,'k-','linewidth',2)
contourf(T-2,X,D,0:0.001:0.1,'linecolor','none')
plot(ts_a,xb_a,'k-','linewidth',2)
contourf(T,X,D,0:0.001:0.1,'linecolor','none')
plot(ts_a+2,xb_a,'k-','linewidth',2)
contourf(T+2,X,D,0:0.001:0.1,'linecolor','none')
set(gca,'FontSize',25)

%labels and ticks
xlabel('$t$ [s]','interpreter','latex','FontSize',40)
xlim([-1 3])
xticks(-1:0.5:3)
xticklabels({'-1.0','','0.0','','1.0','','2.0','','3.0'})
ylabel('$x$ [m]','interpreter','latex','FontSize',40)
ylim([-0.6 1.8])
yticks(-0.6:0.6:1.8)
yticklabels({'-0.6','0.0','0.6','1.2','1.8'})
set(gca,'TickDir','both')

%colorbar
c = colorbar;
clim([0 0.1])
c.Ticks = 0:0.02:0.1;
c.TickLabels = {'0.00','0.02','0.04','0.06','0.08',''};
c.Label.String = '$d$ [m]';
c.Label.Interpreter = 'latex';
c.Label.FontSize = 40;
set(c.Label,'position',[4.3813-3 0.05+0.058 0],'rotation',0);
set(gca,'DataAspectRatio',[2 1 1])
colormap(flipud(slanCM('ice')))
%crameri -devon

% Force Painters renderer (vector-friendly)
set(gcf, 'Renderer', 'Painters');
shading flat;


return


%% Plot Alpha

gsT = 9.81*0.1*2;

figure(1)
clf
hold on
plot(ts_a-2,xb_a,'k-','linewidth',2)
contourf(T-2,X,A-gsT,-3:0.1:3,'linecolor','none')
plot(ts_a,xb_a,'k-','linewidth',2)
contourf(T,X,A,-3:0.1:3,'linecolor','none')
plot(ts_a+2,xb_a,'k-','linewidth',2)
contourf(T+2,X,A+gsT,-3:0.1:3,'linecolor','none')
set(gca,'FontSize',25)

%labels and ticks
xlabel('$t$ [s]','interpreter','latex','FontSize',40)
xlim([-1 3])
xticks(-1:0.5:3)
xticklabels({'-1.0','','0.0','','1.0','','2.0','','3.0'})
ylabel('$x$ [m]','interpreter','latex','FontSize',40)
ylim([-0.6 1.8])
yticks(-0.6:0.6:1.8)
yticklabels({'-0.6','0.0','0.6','1.2','1.8'})
set(gca,'TickDir','both')

%colorbar
c = colorbar;
clim([1 3])
c.Ticks = 1:0.5:3;
c.TickLabels = {'','1.5','2.0','2.5',''};
c.Label.String = '$\alpha$ [m/s]';
c.Label.FontSize = 40;
c.Label.Interpreter = 'latex';
set(c.Label,'position',[4.3813-3 0.05+3.158 0],'rotation',0);
set(gca,'DataAspectRatio',[2 1 1])
crameri -lajolla

% Force Painters renderer (vector-friendly)
set(gcf, 'Renderer', 'Painters');
shading flat;

return

%% Plot Dispersion

figure(1)
clf
hold on
plot(ts_a-2,xb_a,'k-','linewidth',2)
contourf(T-2,X,dudx,-2.5:0.1:2.5,'linecolor','none')
plot(ts_a,xb_a,'k-','linewidth',2)
contourf(T,X,dudx,-2.5:0.1:2.5,'linecolor','none')
plot(ts_a+2,xb_a,'k-','linewidth',2)
contourf(T+2,X,dudx,-2.5:0.1:2.5,'linecolor','none')
set(gca,'FontSize',25)

%labels and ticks
xlabel('$t$ [s]','interpreter','latex','FontSize',40)
xlim([-1 3])
xticks(-1:0.5:3)
xticklabels({'-1.0','','0.0','','1.0','','2.0','','3.0'})
ylabel('$x$ [m]','interpreter','latex','FontSize',40)
ylim([-0.6 1.8])
yticks(-0.6:0.6:1.8)
yticklabels({'-0.6','0.0','0.6','1.2','1.8'})
set(gca,'TickDir','both')

%colorbar
c = colorbar;
clim([-2.5 2.5])
c.Ticks = -2:1:2;
c.TickLabels = {'-2','-1','0','1','2'};
c.Label.String = '$\partial u / \partial x$ [s$^{-1}$]';
c.Label.Interpreter = 'latex';
c.Label.FontSize = 40;
set(c.Label,'position',[4.3813-3.5 0.05+2.958 0],'rotation',0);
set(gca,'DataAspectRatio',[2 1 1])
crameri -tokyo

% Force Painters renderer (vector-friendly)
set(gcf, 'Renderer', 'Painters');
shading flat;



