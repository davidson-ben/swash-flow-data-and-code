%==========================================================================
% contours_data.m
%
% Figure 3 - data
% Plot individual panels for Figure 3 - data results.
% Run each section individually to create each panel.
% 
% Author: B. Davidson
% Last Updated: 3 October 2025
%==========================================================================

clear;
close all;
clc;

%%
%%%%%%%%%%%%
%DATA
%%%%%%%%%%%%


path = "../../Results";

load(strcat(path,'/ea_depth_field.mat'),'Xd','Td','Dd')
load(strcat(path,'/EA_uxt.mat'))
load(strcat(path,'/combined_shoreline_ea.mat'),'t_shore','x_shore')



%% Solve Contours

%x windows
x_width = 0.1; %0.1 m
x_step = 0.05; %0.05 m
%start and end in the swash coords
x_start = -0.75;
x_end = 1.5;
%center of each x window
x_center = x_start:x_step:x_end;

%t windows
t_width = 0.2;
t_step = 0.1;
%start and end in swash time
t_start = 0;
t_end = 2;
%center of each t window
t_center = t_start:t_step:t_end;

[T,X] = meshgrid(t_center,x_center);
N = nan(length(x_center),length(t_center));
nthresh = 10;
U = nan(length(x_center),length(t_center));
D = nan(length(x_center),length(t_center));

for ti = 1:length(t_center)
    t_low = t_center(ti) - t_width/2;
    t_high = t_center(ti) + t_width/2;

    if t_low < 0
        validt = tp>(t_low+2) | tp<t_high;
    elseif t_high >2
        validt = tp>t_low | tp<(t_high-2);
    else
        validt = tp>t_low & tp<t_high;
    end
    for xi = 1:length(x_center)
        x_low = x_center(xi) - x_width/2;
        x_high = x_center(xi) + x_width/2;
        validx = xp>x_low & xp<x_high;

        uvalid = (validx==1 & validt==1);
        N(xi,ti) = sum(uvalid);
        if N(xi,ti)>nthresh
            U(xi,ti) = median(up(uvalid));
            
            D(xi,ti) = thiel_sen(xp(uvalid),up(uvalid));
            %s = polyfit(xp(uvalid),up(uvalid),1);
            %D(xi,ti) = s(1);
        end
    end
end

addpath('./crameri_colormaps')


%% Solve Alpha

Dep_int = interp2(Td,Xd,Dd,T,X);

A = U + 2*sqrt(Dep_int*9.81) + 9.81*(1/10)*T;

%
% figure(3)
% clf
% plot(t_shore,x_shore,'-')
p = polyfit(t_shore(~isnan(x_shore)),x_shore(~isnan(x_shore)),2);
% hold on
% xp = -0.5:0.1:2.5;
% plot(xp,polyval(p,xp),'-')

%clean up alpha cylces
% for ti = 1:size(A,2)
%     if T(1,ti)>1
%         continue
%     end
% 
%     %get shoreline at this time
%     xs_q = polyval(p,T(1,ti));
%     A(X(:,ti)>xs_q,ti) = A(X(:,ti)>xs_q,ti) + 2;
% end


return

%% Velocity Data Plot



figure(1)
clf
hold on
contourf(T-2,X,U,-0.75:0.1:0.75,'linestyle','none')
contourf(T,X,U,-0.75:0.1:0.75,'linecolor','none')
contourf(T+2,X,U,-0.75:0.1:0.75,'linecolor','none')
plot(t_shore-2,x_shore,'k.-','linewidth',2,'markersize',10)
plot(t_shore,x_shore,'k.-','linewidth',2,'markersize',10)
plot(t_shore+2,x_shore,'k.-','linewidth',2,'markersize',10)
set(gca,'FontSize',25)

%labels and ticks
xlabel('$t$ [s]','interpreter','latex','FontSize',40)
xlim([-1 3])
xticks(-1:1:3)
xticklabels({'-1.0','0.0','1.0','2.0','3.0'})
ylabel('$x$ [m]','interpreter','latex','FontSize',40)
ylim([-0.6 1.8])
yticks(-0.6:0.6:1.8)
yticklabels({'-0.6','0.0','0.6','1.2','1.8'})
set(gca,'TickDir','both')



%colorbar
c = colorbar;
clim([-0.75 0.75])
c.Ticks = -0.5:0.25:0.5;
c.TickLabels = {'-0.50','-0.25','0.00','0.25','0.50'};
c.Label.String = '$u$ [m/s]';
c.Label.FontSize = 40
c.Label.Interpreter = 'latex';
set(c.Label,'position',[4.1938-2.5 0+0.95 0],'rotation',0);
set(gca,'DataAspectRatio',[2 1 1])
crameri -roma


return

%% Plot Depth

%Go through depth and if above the shoreline make it nan

%p = polyfit(t_shore(~isnan(x_shore)),x_shore(~isnan(x_shore)),2);

for i = 1:size(Td,2)
    tm = Td(1,i);
    tav = t_shore(t_shore>tm-0.0333/2 & t_shore<tm+0.0333/2);
    xav = x_shore(t_shore>tm-0.0333/2 & t_shore<tm+0.0333/2);
    xst = mean(xav); %average shoreline over bin
    
    %xst = polyval(p,tm);


    pos_rm = Xd(:,1)>xst;
    Dd(pos_rm,i)=nan;

end

figure(1)
clf
hold on
contourf(Td-2,Xd,Dd,50,'linecolor','none')
contourf(Td,Xd,Dd,50,'linecolor','none')
contourf(Td+2,Xd,Dd,50,'linecolor','none')
plot(t_shore-2,x_shore,'k.-','linewidth',2,'markersize',10)
plot(t_shore,x_shore,'k.-','linewidth',2,'markersize',10)
plot(t_shore+2,x_shore,'k.-','linewidth',2,'markersize',10)
set(gca,'FontSize',25)

%labels and ticks
xlabel('$t$ [s]','interpreter','latex','FontSize',40)
xlim([-1 3])
xticks(-1:1:3)
xticklabels({'-1.0','0.0','1.0','2.0','3.0'})
ylabel('$x$ [m]','interpreter','latex','FontSize',40)
ylim([-0.6 1.8])
yticks(-0.6:0.6:1.8)
yticklabels({'-0.6','0.0','0.6','1.2','1.8'})
set(gca,'TickDir','both')



%colorbar
c = colorbar;
clim([0 0.1])
c.Ticks = 0:0.02:0.1;
c.TickLabels = {'0.00','0.02','0.04','0.06','0.08',''};
c.Label.String = '$h$ [m]';
c.Label.FontSize = 40;
c.Label.Interpreter = 'latex';
set(c.Label,'position',[4.3813-3 0.05+0.058 0],'rotation',0);
set(gca,'DataAspectRatio',[2 1 1])
colormap(flipud(slanCM('ice')))

% Force Painters renderer (vector-friendly)
set(gcf, 'Renderer', 'Painters');
shading flat;


return



%% Plot Alpha
gsT = 9.81*0.1*2;

figure(1)
clf
hold on
contourf(T-2,X,A-gsT,100,'linecolor','none')
contourf(T,X,A,100,'linecolor','none')
contourf(T+2,X,A+gsT,100,'linecolor','none')
plot(t_shore-2,x_shore,'k.-','linewidth',2,'markersize',10)
plot(t_shore,x_shore,'k.-','linewidth',2,'markersize',10)
plot(t_shore+2,x_shore,'k.-','linewidth',2,'markersize',10)
set(gca,'FontSize',25)

%labels and ticks
xlabel('$t$ [s]','interpreter','latex','FontSize',40)
xlim([-1 3])
xticks(-1:1:3)
xticklabels({'-1.0','0.0','1.0','2.0','3.0'})
ylabel('$x$ [m]','interpreter','latex','FontSize',40)
ylim([-0.6 1.8])
yticks(-0.6:0.6:1.8)
yticklabels({'-0.6','0.0','0.6','1.2','1.8'})
set(gca,'TickDir','both')


%colorbar
c = colorbar;
clim([1 3])
c.Ticks = 1:0.5:3;
c.TickLabels = {'','1.5','2.0','2.5',''};
c.Label.String = '$\alpha$ [m/s]';
c.Label.FontSize = 40;
c.Label.Interpreter = 'latex';
set(c.Label,'position',[4.3813-3 0.05+3.205 0],'rotation',0);
set(gca,'DataAspectRatio',[2 1 1])
crameri -lajolla

return



%labels and ticks
xlabel('$t$ [s]','interpreter','latex')
xticks(0:0.5:4)
xticklabels({'0.0','0.5','1.0','1.5','2.0','2.5','3.0','3.5','4.0'})
yticks(-0.4:0.4:1.6)
yticklabels({})
set(gca,'TickDir','both')
set(gca,'FontSize',20)
ylim([-0.4 1.6])
ylim([0 0.5])
xlim([0 2.75])


%colorbar
c = colorbar;
clim([1.5 2.5])
%c.Ticks = [1.25:0.25:2.25];
%c.TickLabels = {'1.25','1.50','1.75','2.00','2.25'};
c.Label.String = '$\alpha$ [m/s]';
c.Label.Interpreter = 'latex';
set(c.Label,'position',[3.1313-1.4 1.75+0.85 0],'rotation',0);

set(gca,'DataAspectRatio',[2 1 1])

return

%% Compute alpha in constant region
val = ones(size(A)); %all points start valid

p = polyfit(t_shore(~isnan(x_shore)),x_shore(~isnan(x_shore)),2);

for i = 1:size(T,2)
    tm = T(1,i);
    xs_step = polyval(p,tm);
    val(X(:,i)>xs_step,i) = nan;
end

val(T<0.75) = nan;
val(T>2) = nan;

Aval = A.*val;
val_med_A = round(median(Aval,'all','omitnan'),3)
gsT = round(9.81*0.1*2,3)

pe = abs((val_med_A-gsT)/gsT)*100;
disp(strcat("Percent Error: ",string(round(pe,2)),"%"))


%% Plot Dispersion

figure(1)
clf
hold on
contourf(T-2,X,D,-2.5:0.1:2.5,'LineStyle','none')
contourf(T,X,D,-2.5:0.1:2.5,'LineStyle','none')
contourf(T+2,X,D,-2.5:0.1:2.5,'LineStyle','none')
plot(t_shore-2,x_shore,'k.-','linewidth',2,'markersize',10)
plot(t_shore,x_shore,'k.-','linewidth',2,'markersize',10)
plot(t_shore+2,x_shore,'k.-','linewidth',2,'markersize',10)
set(gca,'FontSize',25)

%labels and ticks
xlabel('$t$ [s]','interpreter','latex','FontSize',40)
xlim([-1 3])
xticks(-1:1:3)
xticklabels({'-1.0','0.0','1.0','2.0','3.0'})
ylabel('$x$ [m]','interpreter','latex','FontSize',40)
ylim([-0.6 1.8])
yticks(-0.6:0.6:1.8)
yticklabels({'-0.6','0.0','0.6','1.2','1.8'})
set(gca,'TickDir','both')

%colorbar
c = colorbar;
clim([-2.5 2.5])
c.Ticks = -2:1:2;
c.TickLabels = {'-2','-1',' 0',' 1',' 2'};
c.Label.String = '$\partial u / \partial x$ [s$^{-1}$]';
c.Label.Interpreter = 'latex';
c.Label.FontSize = 40;
set(c.Label,'position',[4.3813-4.5 0.05+3 0],'rotation',0);
set(gca,'DataAspectRatio',[2 1 1])
crameri -tokyo

% Force Painters renderer (vector-friendly)
set(gcf, 'Renderer', 'Painters');
shading flat;



