function [slope] = thiel_sen(x,y)
%==========================================================================
% thiel_sen.m
%
% Compute local slope via theil-sen estimator.
% 
% Author: B. Davidson
% Last Updated: 3 October 2025
%==========================================================================

    N = length(x);
    loc_slope = nan(nchoosek(N,2),1);
    ind = 1;

    for p1 = 1:N
        for p2 = 1:N
            if p1<p2
                loc_slope(ind) = (y(p2)-y(p1))/(x(p2)-x(p1));
                ind = ind + 1;
            end

        end
    end


    slope = median(loc_slope,'omitnan');

end

