function plot_velocity_ref(v_all,t_all,v_ea,t_ea,side,x1,x2,before,after,xmodel,xmm,Tm,Um)
%==========================================================================
% plot_velocity_ref.m
%
% Function to assist in creating panels for Figure 2.
% 
% Author: B. Davidson
% Last Updated: 3 October 2025
%==========================================================================


plot(t_all,v_all,'c.','MarkerSize',0.5)
hold on
%plot(t_ea,v_ea(:,1),'k--','linewidth',2)
plot(t_ea,v_ea(:,2),'k-','linewidth',2)
%plot(t_ea,v_ea(:,3),'k--','linewidth',2)

if before == 1
    plot(t_all-2,v_all,'c.','MarkerSize',0.5)
    %plot(t_ea-2,v_ea(:,1),'k--','linewidth',2)
    plot(t_ea-2,v_ea(:,2),'k-','linewidth',2)
    %plot(t_ea-2,v_ea(:,3),'k--','linewidth',2)
end
    
if after == 1
    plot(t_all+2,v_all,'c.','MarkerSize',0.5)
    %plot(t_ea+2,v_ea(:,1),'k--','linewidth',2)
    plot(t_ea+2,v_ea(:,2),'k-','linewidth',2)
    %plot(t_ea+2,v_ea(:,3),'k--','linewidth',2)
end


set(gca,'fontsize',35)
yticks(-1:0.5:1)
yticklabels({})

if side == 1
    ylabel('$u$ [m/s]','Interpreter','latex')
    yticklabels({'','-0.5','0.0','0.5',''})
end
ylim([-1 1])


set(gca,'TickDir','both')
xticks(x1:0.5:x2)
xlim([x1 x2])

xticklabels({})


%Model
[~, index] = min(abs(xmm-xmodel));
plot(Tm(:,index),Um(:,index),'r-','linewidth',2)
plot(Tm(:,index)+2,Um(:,index),'r--','linewidth',2)
plot(Tm(:,index)-2,Um(:,index),'r--','linewidth',2)

set(gca,'TickLabelInterpreter','latex')

end

