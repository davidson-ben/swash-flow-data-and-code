function plot_depth_ref(d_all,t_all,d_ea,t_ea,side,tle,x1,x2,before,after,xmodel,xmm,Tm,Dm)
%==========================================================================
% plot_depth_ref.m
%
% Function to assist in creating panels for Figure 2.
% 
% Author: B. Davidson
% Last Updated: 3 October 2025
%==========================================================================


plot(t_all,d_all,'c.','MarkerSize',0.5)
hold on
%plot(t_ea,d_ea(:,1),'k--','linewidth',2)
plot(t_ea,d_ea(:,2),'k-','linewidth',2)
%plot(t_ea,d_ea(:,3),'k--','linewidth',2)

if before == 1
    plot(t_all-2,d_all,'c.','MarkerSize',0.5)
    %plot(t_ea-2,d_ea(:,1),'k--','linewidth',2)
    plot(t_ea-2,d_ea(:,2),'k-','linewidth',2)
    %plot(t_ea-2,d_ea(:,3),'k--','linewidth',2)
end

if after == 1
    plot(t_all+2,d_all,'c.','MarkerSize',0.5)
    %plot(t_ea+2,d_ea(:,1),'k--','linewidth',2)
    plot(t_ea+2,d_ea(:,2),'k-','linewidth',2)
    %plot(t_ea+2,d_ea(:,3),'k--','linewidth',2)
end


set(gca,'fontsize',35)
yticks(0:0.1:0.4)
yticklabels({})

if side == 1
    ylabel('$h$ [m]','Interpreter','latex')
    yticklabels({'0.0','0.1','0.2','0.3',''})
end
ylim([0 0.4])
title(tle)


set(gca,'TickDir','both')
xticks(x1:0.5:x2)
xlim([x1 x2])

xticklabels({})

%Model
[~, index] = min(abs(xmm-xmodel));
plot(Tm(:,index),Dm(:,index),'r-','linewidth',2)
plot(Tm(:,index)+2,Dm(:,index),'r--','linewidth',2)
plot(Tm(:,index)-2,Dm(:,index),'r--','linewidth',2)

set(gca,'TickLabelInterpreter','latex')

end

