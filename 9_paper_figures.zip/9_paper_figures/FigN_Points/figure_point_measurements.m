%==========================================================================
% figure_point_measurements.m
%
% Figure 2
% Plot point measurements and corresponding model for velocity and depth
% with alpha calculation.
% 
% Author: B. Davidson
% Last Updated: 3 October 2025
%==========================================================================

clear;
close all;
clc;

%% Load Data
load WG_locs.mat WG_locs %WG LOCATIONS

load('../../1_camera_preprocessing/A00_SWL.mat')
xs0 = X_swl;
clear X_swl;

load('../../1_camera_preprocessing/cc_smooth.mat') %mm/px conversion


%% Add Antuono
alpha = 2.4607; %non-dimensional


%load antuono solution
load(strcat("../../8_model/alpha2_",string(alpha),".mat"),'X','T','D','xm','U','t0')
Xm = X*1.8;
xmm = xm*1.8;
Tm = (T-t0)*1.3546;
Dm = D*0.18;
Um = U*1.3288;
clear X xm T D U t0


%% Sensors
x = [0  3.5;
     0    2.5;
     -0.5 2;
     -0.5 2;
     -1   1.5;
     -1   1.5;]; %x range of each plot

x = [-1 4; -1 4; -1 4; -1 4; -1 4; -1 4];

xmodel = (xs0-WG_locs(:,1))*mm_px*(1/1000); %x location of each sensor
xmodel = flipud(xmodel);




%%
figure(1)
clf
tiledlayout(3,6,'TileSpacing','tight')
%% Depth

load sw.mat
load("../../Results/depth_ensemble_average.mat")

% deB;   %ensemble average
% dptsB; %all points
% te_dB;    %ensemble average time
% time_cyc;          %all points time
edge = [1 0 0 0 0 0];
tl = {'A','B','C','D','E','F'};



for i = 1:6
    nexttile
    plot_depth_ref(dptsB{i},time_cyc,deB{i},te_dB{i},edge(i),tl{i},x(i,1),x(i,2),1,1,xmodel(i),xmm,Tm,Dm);
    yline(0,'k-')
end


%% Velocity
load("../../Results/velocity_ensemble_average.mat")

%nexttile
% V_B6_ea;   %ensemble average
% V_B6_trim; %all points
% t_V_ea;    %ensemble average time
% t;          %all points time

for i = 1:6
    nexttile
    plot_velocity_ref(uptsB{i},time_cyc,ueB{i},te_uB{i},edge(i),x(i,1),x(i,2),1,1,xmodel(i),xmm,Tm,Um);
end

%% Alpha

alp = 1.85*9.81*0.1;%9.81*0.1*2;

for i = 1:6
    nexttile
    plot_alpha_ref(ueB{i},te_uB{i},deB{i},edge(i),x(i,1),x(i,2),1,1,alp);
    tt = -1:0.1:4;
    gst = 9.81*0.1*tt;
    a_sw = gst + 2*sqrt(9.81*sw(i));
    plot(tt,gst,'b--','linewidth',2)
    %plot(tt,a_sw,'g--','linewidth',2)'

    %plot([-1 4],[alp alp],'g--')
    %plot([-1 4],[alp alp]+9.81*0.1*2,'g:')
end


% Force Painters renderer (vector-friendly)
set(gcf, 'Renderer', 'Painters');
shading flat;
