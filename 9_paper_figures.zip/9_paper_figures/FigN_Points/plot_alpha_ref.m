function plot_alpha_ref(V,T,H,side,x1,x2,before,after,alp)
%==========================================================================
% plot_alpha_ref.m
%
% Function to assist in creating panels for Figure 2.
% 
% Author: B. Davidson
% Last Updated: 3 October 2025
%==========================================================================

A1 = V(:,1) + 2*sqrt(9.81*H(:,1)) + (9.81)*(1/10)*T;
A2 = V(:,2) + 2*sqrt(9.81*H(:,2)) + (9.81)*(1/10)*T;
A3 = V(:,3) + 2*sqrt(9.81*H(:,3)) + (9.81)*(1/10)*T;

hold on
%plot(T,A1,'k--','linewidth',2)
plot(T,A2,'k-','linewidth',2)
%plot(T,A3,'k--','linewidth',2)
%plot([T T+2],9.81*0.1*[T T+2],'r--')

gsT = (9.81)*(1/10)*2;

if before == 1
    %plot(T-2,A1-gsT,'k--','linewidth',2)
    plot(T-2,A2-gsT,'k-','linewidth',2)
    %plot(T-2,A3-gsT,'k--','linewidth',2)
end

if after == 1
    %plot(T+2,A1+gsT,'k--','linewidth',2)
    plot(T+2,A2+gsT,'k-','linewidth',2)
    %plot(T+2,A3+gsT,'k--','linewidth',2)
end

set(gca,'fontsize',35)
set(gca,'TickDir','both')

xlabel('$t$ [s]','interpreter','latex')
xticks(x1:0.5:x2)
xticklabels({'-1','','0','','1','','2','','3','',''})
yticks(0:6)
yticklabels({})
if side == 1
    ylabel('$\alpha$ [m/s]','interpreter','latex')
    yticklabels({'0','','2','','4','',''})
end
ylim([0 6])
xlim([x1 x2])

box on


    %Model
    plot([x1 x2],[alp alp],'r-','linewidth',2)
    plot([x1 x2],[alp-gsT alp-gsT],'r--','linewidth',2)
    plot([x1 x2],[alp+gsT alp+gsT],'r--','linewidth',2)

set(gca,'TickLabelInterpreter','latex')

xtickangle(0)

end

