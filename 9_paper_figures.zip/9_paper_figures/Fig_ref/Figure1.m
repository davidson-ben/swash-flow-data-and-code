%==========================================================================
% figure1.m
%
% Plot Figure 1 - model alpha and shoreline.
% 
% Author: B. Davidson
% Last Updated: 3 October 2025
%==========================================================================

clear;
close all;
clc;

t = 0:0.001:10;
gst = t;
g = 9.81;
s = 1/10;
da = 2;

gsT = 9.81*0.1*2;

figure(1)
clf
subplot(1,2,2)
hold on
plot(t,gst,'blue--','linewidth',4)

RGB = orderedcolors("gem");
alpha1 = @(t) 0*(t<=0) + 1*da*(t>0 & t<=2) + 2*da*(t>2 & t<=4) + 3*da*(t>4 & t<=6) + 4*da*(t>6 & t<=8) + 5*da*(t>8 & t<=10);
plot(t,alpha1(t)-0.25*gsT,'red-','linewidth',4)

%Axis Labels
yticks([0 0.75*gsT 0.75*gsT+gsT])
yticklabels({'$0$','$U_{S0}$','$U_{S0} + \Delta \alpha$'})
xticks([0 2 4])
xticklabels({'$0$','$T$','$2T$'})
ax = gca;
ax.TickLabelInterpreter = 'latex';
set(gca,'FontSize',20)
xlabel('$t$','interpreter','latex')
ylabel('$\alpha$','interpreter','latex')

%Axis limits
ylim([0 4.5])
xlim([0 4.5])

legend({'\alpha_{SW}','\alpha'},'location','best')


%
subplot(1,2,1)
hold on

U_S0 = 0.75*gsT;
xs = U_S0*t - 0.5*g*s*t.^2;

plot(t(1:1501),xs(1:1501),'k-','linewidth',4)
e = 2500;
plot(t(1501:e),xs(1501:e),'k:','linewidth',4)
plot(t(1:1501)+2,xs(1:1501),'k-','linewidth',4)
plot(t(1501:end)+2,xs(1501:end),'k:','linewidth',4)
plot(t(1:1501)+4,xs(1:1501),'k-','linewidth',4)

ylim([0 1.5])
xlim([0 4.5])

%axis labels
yticks([0 0.5 1 1.5])
yticklabels({})
ylabel('$x_S$','interpreter','latex')
xlabel('$t$','interpreter','latex')
xticks([0 2 4])
xticklabels({'$0$','$T$','$2T$'})
ax = gca;
ax.TickLabelInterpreter = 'latex';
set(gca,'FontSize',20)
